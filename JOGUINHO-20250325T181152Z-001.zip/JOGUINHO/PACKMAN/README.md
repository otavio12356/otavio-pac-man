# PyPacman
Pacman clone written in python

# How to test it out

install pygame `pip install pygame`

run main.py `python main.py`.

There are no game overs, play as long as you want. The level keeps on getting reset after you complete it.